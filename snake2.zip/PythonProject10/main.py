import pygame
from settings import *
from snake import Snake

pygame.init()
clock = pygame.time.Clock()

font = pygame.font.SysFont("arial", 32, True)

game = Snake()
running = True

while running:
    clock.tick(FPS+ 0.1 * game.score)
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            running = False

        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_w and game.dir != (1,0):
                game.next_dir = (-1,0)
            if e.key == pygame.K_s and game.dir != (-1,0):
                game.next_dir = (1,0)
            if e.key == pygame.K_a and game.dir != (0,1):
                game.next_dir = (0,-1)
            if e.key == pygame.K_d and game.dir != (0,-1):
                game.next_dir = (0,1)

    game.update()
    game.draw(screen)
    score_text = font.render(f"Рахунок: {game.score}", True, BLACK)
    screen.blit(score_text, (10, 10))
    pygame.display.flip()

pygame.quit()
