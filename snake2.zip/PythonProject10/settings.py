import pygame

WINDOW_W = 600
WINDOW_H = 600
CELL = 50

ROWS = WINDOW_H // CELL
COLS = WINDOW_W // CELL

FPS = 5

screen = pygame.display.set_mode((WINDOW_W, WINDOW_H))
pygame.display.set_caption("Змійка")

GREEN = (75, 180, 75)
LIGHT_GREEN = (95, 200, 95)
BLACK = (0, 0, 0)