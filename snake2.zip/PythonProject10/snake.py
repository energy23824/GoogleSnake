import pygame
from settings import *
from food import Food

class Snake:
    def __init__(self):
        self.food = Food()
        self.reset()

        self.img_head = pygame.image.load("assets/images/head.png")
        self.img_body = pygame.image.load("assets/images/body.png")
        self.img_tail = pygame.image.load("assets/images/tail.png")
        self.img_apple = pygame.image.load("assets/images/apple.png")

        self.turn_images = {
            "turn_ul": pygame.image.load("assets/images/turn_ul.png"),
            "turn_ur": pygame.image.load("assets/images/turn_ur.png"),
            "turn_dl": pygame.image.load("assets/images/turn_dl.png"),
            "turn_dr": pygame.image.load("assets/images/turn_dr.png"),
        }

    def reset(self):
        mid_r = ROWS // 2
        mid_c = COLS // 2

        self.body = [
            {"pos": (mid_r, mid_c), "type": "straight"},
            {"pos": (mid_r, mid_c - 1), "type": "straight"},
            {"pos": (mid_r, mid_c - 2), "type": "straight"},
        ]

        self.dir = (0, 1)
        self.next_dir = (0, 1)
        self.food.place(self.body)
        self.score = 0


    def update(self):
        if self.next_dir != (-self.dir[0], -self.dir[1]):
            prev = self.dir
            self.dir = self.next_dir
            turn = self.get_turn_type(prev, self.dir)
            if turn:
                self.body[0]["type"] = turn

        head_r, head_c = self.body[0]["pos"]
        dr, dc = self.dir
        new_head = (head_r + dr, head_c + dc)

        if not (0 <= new_head[0] < ROWS and 0 <= new_head[1] < COLS) or \
           new_head in [s["pos"] for s in self.body]:
            pygame.time.wait(1000)
            self.reset()
            return

        self.body.insert(0, {"pos": new_head, "type": "straight"})

        # Apple
        if new_head == self.food.position:
            self.food.place(self.body)
            self.score += 1
        else:
            self.body.pop()

        if self.body[-1]["type"].startswith("turn"):
            self.body[-1]["type"] = "straight"

    def get_turn_type(self, prev, new):
        mapping = {
            ((-1,0),(0,-1)):"turn_ul",
            ((-1,0),(0,1)):"turn_ur",
            ((1,0),(0,-1)):"turn_dl",
            ((1,0),(0,1)):"turn_dr",
            ((0,-1),(-1,0)):"turn_dr",
            ((0,-1),(1,0)):"turn_ur",
            ((0,1),(-1,0)):"turn_dl",
            ((0,1),(1,0)):"turn_ul",
        }
        return mapping.get((prev, new), None)

    def rotate(self, img, direction):
        dr, dc = direction
        if (dr, dc) == (0, 1):
            angle = -90
        elif (dr, dc) == (1, 0):
            angle = 180
        elif (dr, dc) == (0, -1):
            angle = 90
        elif (dr, dc) == (-1, 0):
            angle = 0
        else:
            angle = 0
        return pygame.transform.rotate(img, angle)

    # DRAW
    def draw_grid(self, surf):
        for r in range(ROWS):
            for c in range(COLS):
                color = GREEN if (r + c) % 2 == 0 else LIGHT_GREEN
                pygame.draw.rect(surf, color, (c * CELL, r * CELL, CELL, CELL))

    def draw_snake(self, surf):
        for i, seg in enumerate(self.body):
            r, c = seg["pos"]
            x, y = c * CELL, r * CELL

            if i == 0:
                img = self.rotate(self.img_head, self.dir)

            elif i == len(self.body) - 1:
                prev = self.body[i - 1]["pos"]
                dr = prev[0] - r
                dc = prev[1] - c
                img = self.rotate(self.img_tail, (dr, dc))

            elif seg["type"].startswith("turn"):
                img = self.turn_images[seg["type"]]

            else:
                prev = self.body[i - 1]["pos"]
                nxt = self.body[i + 1]["pos"]
                if prev[1] == c and nxt[1] == c:
                    img = pygame.transform.rotate(self.img_body, 90)
                else:
                    img = self.img_body

            img = pygame.transform.scale(img, (CELL, CELL))
            surf.blit(img, (x, y))

    def draw_apple(self, surf):
        r, c = self.food.position
        img = pygame.transform.scale(self.img_apple, (CELL, CELL))
        surf.blit(img, (c * CELL, r * CELL))

    def draw(self, surf):
        self.draw_grid(surf)
        self.draw_apple(surf)
        self.draw_snake(surf)
