import pygame
from settings import *
from snake import Snake
from menu import Menu

pygame.init()
clock = pygame.time.Clock()
font = pygame.font.SysFont("arial", 32, True)

current_diff_settings = DIFFICULTIES["Normal"]
game = Snake(current_diff_settings, sound_enabled=True)

menu = Menu()

app_state = "MENU"
running = True
pygame.mixer.init()
pygame.mixer.music.load("assets/sounds/music.mp3")
pygame.mixer.music.set_volume(0.3)
pygame.mixer.music.play(-1)

while running:
    fps_mult = DIFFICULTIES[menu.difficulty_name]["fps_mult"]
    current_fps = (BASE_FPS * fps_mult) + (0.1 * game.score)
    clock.tick(current_fps)

    events = pygame.event.get()
    for e in events:
        if e.type == pygame.QUIT:
            running = False

        if app_state == "MENU":
            action = menu.handle_event(e)
            if action == "START_GAME":
                selected_settings = DIFFICULTIES[menu.difficulty_name]
                game = Snake(selected_settings, sound_enabled=menu.sound_enabled)

                app_state = "GAME"
            elif action == "EXIT_APP":
                running = False

        elif app_state == "GAME":
            if e.type == pygame.KEYDOWN:
                if game.game_over:
                    if e.key == pygame.K_SPACE:
                        game.reset()
                    if e.key == pygame.K_ESCAPE:
                        app_state = "MENU"
                else:
                    if e.key == pygame.K_ESCAPE: app_state = "MENU"
                    if e.key == pygame.K_SPACE: game.toggle_dive()
                    if e.key == pygame.K_w and game.dir != (1, 0): game.next_dir = (-1, 0)
                    if e.key == pygame.K_s and game.dir != (-1, 0): game.next_dir = (1, 0)
                    if e.key == pygame.K_a and game.dir != (0, 1): game.next_dir = (0, -1)
                    if e.key == pygame.K_d and game.dir != (0, -1): game.next_dir = (0, 1)

    if app_state == "MENU":
        menu.draw(screen)

    elif app_state == "GAME":
        game.update()
        game.draw(screen)

        if not game.game_over:
            score_text = font.render(f"Рахунок: {game.score}", True, (0, 0, 0))
            screen.blit(score_text, (10, 10))

    pygame.display.flip()

pygame.quit()