import pygame
from settings import *
from snake import Snake
from menu import Menu

pygame.mixer.music.play(-1)

clock = pygame.time.Clock()
font = pygame.font.SysFont("arial", 32, True)
font_big = pygame.font.SysFont("arial", 50, True)
font_small = pygame.font.SysFont("arial", 30, True)
font_mini = pygame.font.SysFont("arial", 20, True)
font_title = pygame.font.SysFont("arial", 64, True)

game = Snake(DIFFICULTIES["Normal"], sound_enabled=True)
menu = Menu()

app_state = "MENU"
running = True

def rotate_img(img, direction):
    dr, dc = direction
    angles = {(0, 1): -90, (1, 0): 180, (0, -1): 90, (-1, 0): 0}
    return pygame.transform.rotate(img, angles.get((dr, dc), 0))

def draw_grid(game):
    for r in range(game.rows):
        for c in range(game.cols):
            color = GREEN if (r + c) % 2 == 0 else LIGHT_GREEN
            pygame.draw.rect(screen, color, (c * game.cell_size, r * game.cell_size, game.cell_size, game.cell_size))

def draw_snake(game):
    alpha = 100 if game.is_diving else 255
    cell = game.cell_size

    for i, seg in enumerate(game.body):
        r, c = seg["pos"]
        x, y = c * cell, r * cell

        if i == 0:
            img = rotate_img(img_head, game.dir)
        elif i == len(game.body) - 1:
            prev = game.body[i - 1]["pos"]
            dr, dc = prev[0] - r, prev[1] - c
            img = rotate_img(img_tail, (dr, dc))
        elif seg["type"].startswith("turn"):
            img = turn_images[seg["type"]]
        else:
            prev = game.body[i - 1]["pos"]
            nxt = game.body[i + 1]["pos"]
            if prev[1] == c and nxt[1] == c:
                img = pygame.transform.rotate(img_body, 90)
            else:
                img = img_body

        img_copy = img.copy()
        img_copy.set_alpha(alpha)
        img_copy = pygame.transform.scale(img_copy, (cell, cell))
        screen.blit(img_copy, (x, y))

def draw_food(game):
    r, c = game.food.position
    cell = game.cell_size
    img = img_apple if game.food.type == "apple" else img_banana
    img = pygame.transform.scale(img, (cell, cell))
    screen.blit(img, (c * cell, r * cell))

def draw_rocks(game):
    cell = game.cell_size
    for r, c in game.rocks.positions:
        img = pygame.transform.scale(img_rock, (cell, cell))
        screen.blit(img, (c * cell, r * cell))

def draw_palms(game):
    cell = game.cell_size
    for r, c in game.palms.positions:
        img = pygame.transform.scale(img_palma, (cell, cell))
        screen.blit(img, (c * cell, r * cell))

def draw_ui(game):
    score_text = font.render(f"Рахунок: {game.score}", True, BLACK)
    screen.blit(score_text, (10, 10))

    bar_width, bar_height = 200, 20
    x, y = WINDOW_W - bar_width - 10, 10

    pygame.draw.rect(screen, (50, 50, 50), (x, y, bar_width, bar_height))
    oxygen_ratio = max(0, game.oxygen / game.oxygen_max)
    fill_width = int(bar_width * oxygen_ratio)
    color = BLUE if oxygen_ratio > 0.25 else RED
    pygame.draw.rect(screen, color, (x, y, fill_width, bar_height))
    pygame.draw.rect(screen, WHITE, (x, y, bar_width, bar_height), 2)

    oxy_font = pygame.font.SysFont("arial", 14, True)
    text = oxy_font.render("Кисень", True, WHITE)
    screen.blit(text, (x + 70, y + 2))


def draw_death_screen(game):
    overlay = pygame.Surface((WINDOW_W, WINDOW_H), pygame.SRCALPHA)
    overlay.fill(DARK_OVERLAY)
    screen.blit(overlay, (0, 0))

    texts = [
        (font_big.render("Ти програв!", True, RED), -60),
        (font_small.render(f"Рахунок: {game.score}", True, WHITE), 0),
        (font_small.render(f"Рекорд: {game.high_score}", True, WHITE), 40),
        (font_small.render("Натисни SPACE для рестарту", True, WHITE), 100),
        (font_mini.render("Натисни ESC для переходу в меню", True, WHITE), 140),
    ]
    for text, offset in texts:
        rect = text.get_rect(center=(WINDOW_W // 2, WINDOW_H // 2 + offset))
        screen.blit(text, rect)


def draw_game(game):
    draw_grid(game)
    draw_rocks(game)
    draw_palms(game)
    draw_food(game)
    draw_snake(game)
    if not game.game_over:
        draw_ui(game)
    else:
        draw_death_screen(game)

def draw_menu(menu):
    bg = pygame.transform.scale(img_menu_bg, (WINDOW_W, WINDOW_H))
    screen.blit(bg, (0, 0))

    title_txt = "ЗМІЙКА" if menu.state == "MAIN" else "НАЛАШТУВАННЯ"

    outline = font_title.render(title_txt, True, BLACK)
    screen.blit(outline, (WINDOW_W // 2 - outline.get_width() // 2 + 3, 103))

    title = font_title.render(title_txt, True, GREEN)
    screen.blit(title, (WINDOW_W // 2 - title.get_width() // 2, 100))

    buttons = menu.main_buttons if menu.state == "MAIN" else menu.settings_buttons
    for btn in buttons:
        btn.draw(screen)


while running:
    if app_state == "MENU":
        clock.tick(60)
    else:
        fps = (BASE_FPS * DIFFICULTIES[menu.difficulty_name]["fps_mult"]) + (0.1 * game.score)
        clock.tick(fps)

    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            running = False

        if app_state == "MENU":
            action = menu.handle_event(e)
            if action == "START_GAME":
                game = Snake(DIFFICULTIES[menu.difficulty_name], sound_enabled=menu.sound_enabled)
                app_state = "GAME"
            elif action == "EXIT_APP":
                running = False

        elif app_state == "GAME":
            if e.type == pygame.KEYDOWN:
                if game.game_over:
                    if e.key == pygame.K_SPACE:
                        game.reset()
                    if e.key == pygame.K_ESCAPE:
                        app_state = "MENU"
                else:
                    if e.key == pygame.K_ESCAPE:
                        app_state = "MENU"
                    if e.key == pygame.K_SPACE:
                        game.toggle_dive()
                    if e.key == pygame.K_w and game.dir != (1, 0):
                        game.next_dir = (-1, 0)
                    if e.key == pygame.K_s and game.dir != (-1, 0):
                        game.next_dir = (1, 0)
                    if e.key == pygame.K_a and game.dir != (0, 1):
                        game.next_dir = (0, -1)
                    if e.key == pygame.K_d and game.dir != (0, -1):
                        game.next_dir = (0, 1)

    if app_state == "MENU":
        draw_menu(menu)
    elif app_state == "GAME":
        game.update()
        draw_game(game)

    pygame.display.flip()

pygame.quit()