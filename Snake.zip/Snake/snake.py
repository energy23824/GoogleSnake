import pygame
from settings import *
from food import Food, Rocks, Palms

class Snake:
    def __init__(self, difficulty_settings, sound_enabled=True):
        self.high_score = 0
        self.sound_enabled = sound_enabled

        self.cell_size = difficulty_settings["cell"]
        self.rock_count = difficulty_settings["rocks"]
        self.palm_count = difficulty_settings["palms"]

        self.rows = WINDOW_H // self.cell_size
        self.cols = WINDOW_W // self.cell_size

        self.food = Food()
        self.rocks = Rocks(self.rock_count)
        self.palms = Palms(self.palm_count)

        self.reset()

    def reset(self):
        mid_r = self.rows // 2
        mid_c = self.cols // 2

        self.body = [
            {"pos": (mid_r, mid_c), "type": "straight"},
            {"pos": (mid_r, mid_c - 1), "type": "straight"},
            {"pos": (mid_r, mid_c - 2), "type": "straight"},
        ]

        self.dir = (0, 1)
        self.next_dir = (0, 1)
        self.score = 0
        self.game_over = False

        self.is_diving = False
        self.oxygen_max = BASE_FPS * 5
        self.oxygen = self.oxygen_max

        self.rocks.place(self.body, self.rows, self.cols)
        self.palms.place(self.body, self.rocks.positions, self.rows, self.cols)
        self.food.place(self.body, self.rocks.positions, self.palms.positions, self.rows, self.cols)

    def toggle_dive(self):
        if self.is_diving:
            self.is_diving = False
        else:
            if self.oxygen > self.oxygen_max * 0.1:
                self.is_diving = True

    def game_over_logic(self):
        if not self.game_over and self.sound_enabled:
            snd_lose.play()

        self.game_over = True
        if self.score > self.high_score:
            self.high_score = self.score

    def update(self):
        if self.game_over:
            return

        # Кисень
        if self.is_diving:
            self.oxygen -= 3
            if self.oxygen <= 0:
                self.oxygen = 0
                self.is_diving = False
                self.game_over_logic()
        else:
            if self.oxygen < self.oxygen_max:
                self.oxygen += 1

        # Поворот
        if self.next_dir != (-self.dir[0], -self.dir[1]):
            prev = self.dir
            self.dir = self.next_dir
            turn = self.get_turn_type(prev, self.dir)
            if turn:
                self.body[0]["type"] = turn

        # Нова голова
        head_r, head_c = self.body[0]["pos"]
        dr, dc = self.dir
        new_head = (head_r + dr, head_c + dc)

        # Стіни
        if not (0 <= new_head[0] < self.rows and 0 <= new_head[1] < self.cols):
            self.game_over_logic()
            return

        # Перешкоди
        if self.is_diving:
            if new_head in self.palms.positions:
                self.game_over_logic()
                return
        else:
            if new_head in [s["pos"] for s in self.body] or \
                    new_head in self.rocks.positions or \
                    new_head in self.palms.positions:
                self.game_over_logic()
                return

        self.body.insert(0, {"pos": new_head, "type": "straight"})

        # Їжа
        if new_head == self.food.position:
            if self.food.type == "apple":
                self.score += 1
            elif self.food.type == "banana":
                self.score += 2
            if self.sound_enabled:
                snd_eat.play()
            self.food.place(self.body, self.rocks.positions, self.palms.positions, self.rows, self.cols)
        else:
            self.body.pop()

        if self.body[-1]["type"].startswith("turn"):
            self.body[-1]["type"] = "straight"

    def get_turn_type(self, prev, new):
        mapping = {
            ((-1, 0), (0, -1)): "turn_ul", ((-1, 0), (0, 1)): "turn_ur",
            ((1, 0), (0, -1)): "turn_dl", ((1, 0), (0, 1)): "turn_dr",
            ((0, -1), (-1, 0)): "turn_dr", ((0, -1), (1, 0)): "turn_ur",
            ((0, 1), (-1, 0)): "turn_dl", ((0, 1), (1, 0)): "turn_ul",
        }
        return mapping.get((prev, new), None)