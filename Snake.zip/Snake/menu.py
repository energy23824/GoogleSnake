import pygame
from settings import *

class Button:
    def __init__(self, text, x, y, w, h, action_id):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text
        self.action_id = action_id
        self.font = pygame.font.SysFont("arial", 28, True)
        self.hovered = False

    def draw(self, surf):
        color = BUTTON_HOVER if self.hovered else BUTTON_NORMAL
        pygame.draw.rect(surf, color, self.rect, border_radius=10)
        pygame.draw.rect(surf, WHITE, self.rect, 2, border_radius=10)

        text_surf = self.font.render(self.text, True, BUTTON_TEXT)
        text_rect = text_surf.get_rect(center=self.rect.center)
        surf.blit(text_surf, text_rect)

    def check_hover(self, mouse_pos):
        self.hovered = self.rect.collidepoint(mouse_pos)

    def check_click(self, mouse_pos):
        if self.hovered: return self.action_id
        return None


class Menu:
    def __init__(self):
        self.state = "MAIN"
        self.difficulty_name = "Normal"
        self.sound_enabled = True  # Нова змінна стану

        cx = WINDOW_W // 2
        w, h = 200, 50

        self.main_buttons = [
            Button("Грати", cx - 100, 200, w, h, "play"),
            Button("Налаштування", cx - 100, 270, w, h, "settings"),
            Button("Вийти", cx - 100, 340, w, h, "exit")
        ]

        # Оновлені кнопки налаштувань (додано звук)
        self.settings_buttons = [
            Button("Складність: Normal", cx - 150, 180, 300, h, "toggle_diff"),
            Button("Звук: ON", cx - 100, 250, w, h, "toggle_sound"),  # Кнопка звуку
            Button("Назад", cx - 100, 320, w, h, "back")
        ]

    def update_difficulty_button(self):
        self.settings_buttons[0].text = f"Складність: {self.difficulty_name}"

    def update_sound_button(self):
        # Оновлюємо текст кнопки залежно від стану
        state = "ON" if self.sound_enabled else "OFF"
        self.settings_buttons[1].text = f"Звук: {state}"

    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            mouse_pos = pygame.mouse.get_pos()
            buttons = self.main_buttons if self.state == "MAIN" else self.settings_buttons
            for btn in buttons: btn.check_hover(mouse_pos)

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                mouse_pos = pygame.mouse.get_pos()
                buttons = self.main_buttons if self.state == "MAIN" else self.settings_buttons
                for btn in buttons:
                    action = btn.check_click(mouse_pos)
                    if action: return self.perform_action(action)
        return None

    def perform_action(self, action):
        if action == "play":
            return "START_GAME"
        elif action == "exit":
            return "EXIT_APP"
        elif action == "settings":
            self.state = "SETTINGS"
        elif action == "back":
            self.state = "MAIN"
        elif action == "toggle_diff":
            self.cycle_difficulty()
        elif action == "toggle_sound":
            self.toggle_sound()  # Обробка кліку
        return None

    def toggle_sound(self):
        self.sound_enabled = not self.sound_enabled
        self.update_sound_button()

    def cycle_difficulty(self):
        modes = ["Normal", "Hard", "Easy"]
        current_idx = modes.index(self.difficulty_name)
        next_idx = (current_idx + 1) % len(modes)
        self.difficulty_name = modes[next_idx]
        self.update_difficulty_button()

    def draw(self, surf):
        surf.fill(LIGHT_GREEN)
        font_title = pygame.font.SysFont("arial", 50, True)
        title_text = "SNAKE: UNDERGROUND" if self.state == "MAIN" else "НАЛАШТУВАННЯ"
        title_surf = font_title.render(title_text, True, (0, 80, 0))
        title_rect = title_surf.get_rect(center=(WINDOW_W // 2, 100))
        surf.blit(title_surf, title_rect)

        buttons = self.main_buttons if self.state == "MAIN" else self.settings_buttons
        for btn in buttons: btn.draw(surf)