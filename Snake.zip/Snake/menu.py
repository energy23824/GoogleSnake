import pygame
from settings import *
from button import Button


class Menu:
    def __init__(self):
        self.state = "MAIN"
        self.difficulty_name = "Normal"
        self.sound_enabled = True
        self.music_enabled = True

        cx = WINDOW_W // 2
        w, h = 240, 60

        self.main_buttons = [
            Button("Грати", cx - w // 2, 250, w, h, "play"),
            Button("Налаштування", cx - w // 2, 330, w, h, "settings"),
            Button("Вийти", cx - w // 2, 410, w, h, "exit")
        ]

        self.settings_buttons = [
            Button("Складність: Normal", cx - 150, 200, 300, h, "toggle_diff"),
            Button("Звук: ON", cx - 150, 270, 300, h, "toggle_sound"),
            Button("Музика: ON", cx - 150, 340, 300, h, "toggle_music"),
            Button("Назад", cx - 100, 420, 200, h, "back")
        ]

    def update_difficulty_button(self):
        self.settings_buttons[0].text = f"Складність: {self.difficulty_name}"

    def update_sound_button(self):
        self.settings_buttons[1].text = f"Звук: {'ON' if self.sound_enabled else 'OFF'}"

    def update_music_button(self):
        self.settings_buttons[2].text = f"Музика: {'ON' if self.music_enabled else 'OFF'}"

    def toggle_sound(self):
        self.sound_enabled = not self.sound_enabled
        self.update_sound_button()

    def toggle_music(self):
        self.music_enabled = not self.music_enabled
        self.update_music_button()
        pygame.mixer.music.set_volume(0.3 if self.music_enabled else 0)

    def cycle_difficulty(self):
        modes = ["Normal", "Hard", "Easy"]
        i = modes.index(self.difficulty_name)
        self.difficulty_name = modes[(i + 1) % len(modes)]
        self.update_difficulty_button()

    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            buttons = self.main_buttons if self.state == "MAIN" else self.settings_buttons
            for btn in buttons:
                btn.check_hover(pygame.mouse.get_pos())

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            buttons = self.main_buttons if self.state == "MAIN" else self.settings_buttons
            for btn in buttons:
                action = btn.check_click(pygame.mouse.get_pos())
                if action:
                    return self.perform_action(action)
        return None

    def perform_action(self, action):
        match action:
            case "play": return "START_GAME"
            case "exit": return "EXIT_APP"
            case "settings": self.state = "SETTINGS"
            case "back": self.state = "MAIN"
            case "toggle_diff": self.cycle_difficulty()
            case "toggle_sound": self.toggle_sound()
            case "toggle_music": self.toggle_music()
        return None