import random
from settings import ROWS, COLS

class Food:
    def __init__(self):
        self.position = (0, 0)

    def place(self, snake_body):
        while True:
            r = random.randint(0, ROWS - 1)
            c = random.randint(0, COLS - 1)
            if (r, c) not in [s["pos"] for s in snake_body]:
                self.position = (r, c)
                break
