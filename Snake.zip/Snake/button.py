import pygame
from settings import *


class Button:
    def __init__(self, text, x, y, w, h, action_id):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text
        self.action_id = action_id
        self.font = pygame.font.SysFont("arial", 26, True)
        self.hovered = False

    def check_hover(self, mouse_pos):
        self.hovered = self.rect.collidepoint(mouse_pos)

    def check_click(self, mouse_pos):
        if self.rect.collidepoint(mouse_pos):
            return self.action_id
        return None

    def draw(self, surf):
        if self.hovered:
            bg_color = (50, 100, 200)
            border_color = WHITE
        else:
            bg_color = GREEN
            border_color = (200, 200, 200)

        button_surf = pygame.Surface((self.rect.width, self.rect.height), pygame.SRCALPHA)
        pygame.draw.rect(button_surf, (*bg_color, 220), (0, 0, self.rect.width, self.rect.height), border_radius=12)
        pygame.draw.rect(button_surf, border_color, (0, 0, self.rect.width, self.rect.height), 3, border_radius=12)
        surf.blit(button_surf, self.rect.topleft)

        text_surf = self.font.render(self.text, True, WHITE)
        text_rect = text_surf.get_rect(center=self.rect.center)
        surf.blit(text_surf, text_rect)