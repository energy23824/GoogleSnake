import pygame

WINDOW_W = 600
WINDOW_H = 600

BASE_FPS = 7

screen = pygame.display.set_mode((WINDOW_W, WINDOW_H))
pygame.display.set_caption("Змійка")

DIFFICULTIES = {
    "Easy":   {"cell": 50, "rocks": 3, "palms": 2, "fps_mult": 0.8},
    "Normal": {"cell": 40, "rocks": 7, "palms": 4, "fps_mult": 0.9},
    "Hard":   {"cell": 30, "rocks": 15, "palms": 8, "fps_mult": 1.0},
}

GREEN = (75, 180, 75)
LIGHT_GREEN = (95, 200, 95)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (200, 50, 50)
BLUE = (50, 50, 200)
DARK_OVERLAY = (0, 0, 0, 150)

BUTTON_NORMAL = (70, 130, 180)
BUTTON_HOVER = (100, 149, 237)
BUTTON_TEXT = (255, 255, 255)

OXYGEN_SECONDS = 5