import pygame

pygame.init()
pygame.mixer.init()

WINDOW_W = 600
WINDOW_H = 600
BASE_FPS = 7

screen = pygame.display.set_mode((WINDOW_W, WINDOW_H))
pygame.display.set_caption("Змійка")

DIFFICULTIES = {
    "Easy":   {"cell": 50, "rocks": 3, "palms": 2, "fps_mult": 0.8},
    "Normal": {"cell": 40, "rocks": 7, "palms": 4, "fps_mult": 0.9},
    "Hard":   {"cell": 30, "rocks": 15, "palms": 8, "fps_mult": 1.0},
}

GREEN = (75, 180, 75)
LIGHT_GREEN = (95, 200, 95)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (200, 50, 50)
BLUE = (50, 50, 200)
DARK_OVERLAY = (0, 0, 0, 150)

img_head = pygame.image.load("assets/images/head.png").convert_alpha()
img_body = pygame.image.load("assets/images/body.png").convert_alpha()
img_tail = pygame.image.load("assets/images/tail.png").convert_alpha()
img_apple = pygame.image.load("assets/images/apple.png").convert_alpha()
img_banana = pygame.image.load("assets/images/banana.png").convert_alpha()
img_rock = pygame.image.load("assets/images/rock.png").convert_alpha()
img_palma = pygame.image.load("assets/images/palma.png").convert_alpha()
img_menu_bg = pygame.image.load("assets/images/menu_bg.png").convert()

turn_images = {
    "turn_ul": pygame.image.load("assets/images/turn_ul.png").convert_alpha(),
    "turn_ur": pygame.image.load("assets/images/turn_ur.png").convert_alpha(),
    "turn_dl": pygame.image.load("assets/images/turn_dl.png").convert_alpha(),
    "turn_dr": pygame.image.load("assets/images/turn_dr.png").convert_alpha(),
}

snd_eat = pygame.mixer.Sound("assets/sounds/apple_eat.wav")
snd_lose = pygame.mixer.Sound("assets/sounds/lose.wav")
snd_eat.set_volume(0.5)
snd_lose.set_volume(0.5)
pygame.mixer.music.load("assets/sounds/music.mp3")
pygame.mixer.music.set_volume(0.2)